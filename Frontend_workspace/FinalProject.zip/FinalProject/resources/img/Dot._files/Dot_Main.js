$(document).ready(function(){
    $('.feed-img').slick({
      // Slick configuration options
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows : true,
      // dots:true
      // Add more options as needed
    });
  });